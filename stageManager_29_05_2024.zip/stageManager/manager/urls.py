from django.contrib import admin
from django.urls import path
from .import views

urlpatterns = [
    path('', views.index, name='index'),
    path('home/<str:niveau>/<str:nom_filier>/<int:year>/<str:cin>', views.home, name='home'),
    path('erreur/', views.erreur, name='erreur'),
    path('newdossier/<str:niveau>/<str:nom_filier>/<int:year>', views.newdossier, name='newdossier'),
    path('delete/<int:pk>', views.deletedossier, name='deletedossier'),
    path('afficherdossier/<int:pk>', views.afficherdossier, name='afficherdossier'),
    path('updatedossier/<int:pk>', views.updatedossier, name='updatedossier'),
    path('logout/', views.deconexion, name='logout'),
    path('register/', views.register, name='register'),
    path('FiliereEtudiant/', views.filiereEtudiant, name='FiliereEtud'),
    path('deleteFiliere/<int:pk>/<str:niveau>/<int:year>', views.deleteFiliere, name='deleteFiliere'),
    path('newFiliere', views.newFiliere, name='newFiliere'),
    path('filiereProf/', views.filiereProf, name='filiereProf'),
    
    path('filiereAdmin/', views.filieresAdmin, name='filiereAdmin'),

    path('ajoutFilierAdmin/', views.ajoutFilierAdmin, name='ajoutFilierAdmin'),

    path('updateFiliere/<int:pk>', views.updateFiliere, name='updateFiliere'),

    path('etudiantsFil/<str:niveau>/<str:filiere>/<int:Year>', views.etudiantsFiliere, name='etudiantsFil'),

    path('listeProfs/', views.listProfs, name='listProfs'),
    path('ajoutProf/', views.ajoutProf, name='ajoutProf'),
]


