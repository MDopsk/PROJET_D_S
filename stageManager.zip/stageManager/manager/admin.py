from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User,Dossiers, Student, Prof


class Etud(UserAdmin):
    model=Student
    fieldsets = UserAdmin.fieldsets + (
        (None, {'fields': ('adresse','tel','Napog','CNE','dateN','lieuxN')}),
    )

class Professeur(UserAdmin):
    model=Student
    fieldsets = UserAdmin.fieldsets + (
        (None, {'fields': ('adresse','tel','dateN','lieuxN', 'SPC')}),
    )

admin.site.register(Student, Etud)
admin.site.register(Prof, Professeur)
admin.site.register(Dossiers)
# Register your models here.
