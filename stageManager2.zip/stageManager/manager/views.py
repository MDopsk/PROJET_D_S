from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from .models import Dossiers, Student, StudenttFiliere, Domaine, Filiere

# Create your views here.
def index(request):
    user=None
    if request.method=='POST':
        username = request.POST["CIN"]
        password = request.POST["PW"]
        user = authenticate(request, username=username, password=password)
        if user is not None:
        # Redirect to a success page.
            login(request, user)
            return redirect('FiliereEtud')
        else:
        # Return an 'invalid login' error message.
            return redirect('erreur')
    else:
    
        return render(request, 'manager/index.html', {'user': user}) 
    
       

def home(request):
   if request.user.is_authenticated:
        dossiers = Dossiers.objects.filter(Student =request.user)
        context = {'dossiers':dossiers, 'user_name':request.user.username,  'first_name':request.user.first_name, 'last_name':request.user.last_name}
        return render(request, 'manager/home.html',context = context)
   else:
        return redirect('erreur')


def erreur(request):
    return render(request, 'manager/erreur.html')


def newdossier(request):
   
    if request.method=='POST':
        typ = request.POST['Type']
        rapport=request.POST['Rapport']
        dossier=request.POST['Dossier']
        sujet=request.POST['Sujet']
        encadrant=request.POST['Encadrant']
        domaine=request.POST['Domaine']
        student=request.user
        d=Dossiers.objects.create(Type=typ, Rapport=rapport, Doss=dossier, Sujet=sujet, Encadrant=encadrant, Domaine=domaine, Student=student )
        d.save()
        return redirect('home')
    else:
        sf = StudenttFiliere.objects.get(Etudiant = request.user)
        d = Domaine.objects.filter(filiere = sf.pk)
        
        
        return render(request, 'manager/newdossier.html', { 'TypesStage': Dossiers.TYPES , 'domaines': d})
    
def deletedossier(request, pk):
    
    d=Dossiers.objects.filter(pk=pk)
    if request.method == 'POST':
        d.delete()
        return redirect('home')

def afficherdossier(request, pk):
    dossier = Dossiers.objects.get(pk=pk)
    context = { 'dossier':dossier }
    return render(request, 'manager/afficherdossier.html', context=context)

def updatedossier(request, pk):
    if request.method =='POST':
        typ=request.POST['Type']
        rapport=request.POST['Rapport']
        doss=request.POST['Dossier']
        sujet=request.POST['Sujet']
        encadrant=request.POST['Encadrant']
        domaine=request.POST['Domaine']

        dossier = Dossiers.objects.get(pk=pk)

        dossier.Type = typ
        dossier.Rapport=rapport
        dossier.Doss =doss
        dossier.Sujet =sujet
        dossier.Encadrant=encadrant
        dossier.Domaine=domaine
        dossier.save()
        return redirect('home')
    
    
    dossier = Dossiers.objects.get(pk=pk)
    context = { 'dossier':dossier }
    return render(request, 'manager/updatedossier.html', context=context)




def deconexion(request):
    logout(request)
    return redirect('index')


def register(request):

    if request.method =='POST':
        Napog=request.POST['Napog']
        CIN=request.POST['CIN']
        CNE=request.POST['CNE']
        Nom=request.POST['Nom']
        prenom=request.POST['prenom']
        adresse=request.POST['adresse']
        tel=request.POST['tel']
        DateN=request.POST['DateN']
        LieuxN=request.POST['LieuxN']
        pw1=request.POST['pw1']
        pw2=request.POST['pw2']

        

        if pw1 != pw2:
            erreur ="Les mots de passe ne correspondent pas. Veuillez les saisir à nouveau."
            context = {'register': True, 'erreur':erreur, 'Napog':Napog, 'CIN':CIN, 'CNE':CNE, 'Nom':Nom, 'prenom':prenom,'adresse':adresse, 'tel':tel, 'DateN':DateN, 'LieuxN':LieuxN}
            return render(request, 'manager/enregistrement.html', context=context)
    
        Student.objects.create_user(Napog=Napog, username=CIN, CNE=CNE, first_name=Nom, last_name=prenom, adresse=adresse,  tel=tel, dateN=DateN, lieuxN=LieuxN, password=pw1)
        
        return redirect('index')
    context = {'register': True, }
    return render(request, 'manager/enregistrement.html', context=context)

def filiereEtudiant(request):
    
       if request.user.is_authenticated:
        FiliereEtud = StudenttFiliere.objects.filter(Etudiant =request.user)
        
        
        context = {'Filieres':FiliereEtud, 'user_name':request.user.username,  'first_name':request.user.first_name, 'last_name':request.user.last_name}
        return render(request, 'manager/FiliereEtud.html',context = context)
       else:
        return redirect('index')

def deleteFiliere(request, pk):
    #si valider ou commenter n'est pas effacer
   
    if request.method == 'POST':
        f= Filiere.objects.filter(pk=pk)
        f.delete()
        return redirect('FiliereEtud')

def newFiliere(request):
       
    if request.method=='POST':
        pk=request.POST['NomFiliere']
        annee=request.POST['Annee']
        student=request.user
        
        f=Filiere.objects.get(pk=pk)
        
        se =StudenttFiliere.objects.create(Etudiant=student, Filiere=f, Year=f"{annee}-01-01")
        se.save()
        return redirect('FiliereEtud')
    else:
        sf = Filiere.objects.all()
        
        return render(request, 'manager/newFiliere.html', {'Filieres': sf})
    