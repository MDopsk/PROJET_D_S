from typing import Iterable
from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager

# Create your models here.

class User(AbstractUser):
    class Role(models.TextChoices):
        ADMIN="ADMIN", 'ADMIN'
        PROF="PROF", 'PROF'
        ETUDIANT="ETUDIANT", 'ETUDIANT'
   
    base_role=Role.ADMIN
    base_role1=Role.ETUDIANT
    role = models.CharField(max_length = 20, choices= Role)
     
    #adresse
    adresse=models.TextField(max_length=150,null=True)
    #tel
    tel=models.CharField(max_length=40,null=True)

    #N_apog
    Napog=models.IntegerField(default=0,null=True)
    #CNE
    CNE=models.CharField(max_length=50,null=True)
    #date_n
    dateN= models.DateField(auto_now=False, auto_now_add=False, null=True)
    #lieux_n
    lieuxN = models.CharField(max_length=50,null=True)
    
    
    #spc
    SPC = models.CharField(max_length = 50,null=True)

    def save(self, *args, **kwargs):
        if not self.pk:
            self.role=self.base_role
            return super().save(*args, **kwargs)





class ProfManager(BaseUserManager):
    def get_queryset(self, *args, **kwargs):
        result=super().get_queryset(*args, **kwargs)
        return result.filter(role=User.Role.PROF)
        

class Prof(User):
    base_role=User.Role.PROF
    prof=ProfManager()
    def save(self, *args, **kwargs):
        return super().save(*args, **kwargs)
    class Meta:
        proxy=True

class StudentManager(BaseUserManager):
    def get_queryset(self, *args, **kwargs):
        result=super().get_queryset(*args, **kwargs)
        return result.filter(role=User.Role.ETUDIANT)
    
        

class Student(User):
    base_role=User.Role.ETUDIANT
    student=StudentManager()
    def save(self, *args, **kwargs):
        return super().save(*args, **kwargs)
    class Meta:
        proxy=True



class Dossiers(models.Model):
    TYPES = (
        ("Stage d'initiation", "Stage d'initiation"),
        ('Stage technique', 'stage technique'),
        ('Stage PFE', 'stage PFE'),
        ('Stage Professionel', 'Stage Professionel'),
    )
    NIVEAUX = (
        ("1ere Annee", "1ere Annee"),
        ("2 eme Annee", "2eme Annee"),
        ('Liecsence Professionelle', 'Liecsence Professionelle'),
    )
    Type = models.CharField(max_length=50, choices=TYPES)
    Rapport = models.CharField(max_length=100)
    Doss= models.CharField(max_length=100)
    Sujet = models.CharField(max_length=100)
    Encadrant = models.CharField(max_length=100)
    Domaine = models.CharField(max_length=100)
    Niveau = models.CharField(max_length=50, choices = NIVEAUX)
    Student = models.ForeignKey(Student, on_delete=models.CASCADE)
    ValidationProf = models.BooleanField(default=False)
    ValidationAdmin = models.BooleanField(default=False)
    RemarqueProf = models.CharField(max_length=255, blank=True, null=True)
    RemarqueAdmin = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return f"{self.Sujet} {self.Domaine}"
    
    
# Modèle pour la filière
class Filiere(models.Model):
    NIVEAUX = (
        ("1ere Annee", "1ere Annee"),
        ("2eme Annee", "2eme Annee"),
        ('Liecsence Professionelle', 'Liecsence Professionelle'),
    )
    Nom_filiere = models.CharField(max_length=100) 
    Niveau = models.CharField(max_length=50 , choices = NIVEAUX)
    def __str__(self):
        return f"{self.Nom_filiere} {self.Niveau}"
    
    
#modele pour le domaine    
class Domaine(models.Model):
    NomDomaine = models.CharField(max_length=100) 
    filiere = models.ForeignKey( Filiere , on_delete=models.CASCADE)
    def __str__(self):
        return self.NomDomaine
    
    
    

# Modèle pour la relation entre étudiant et filière
class StudenttFiliere(models.Model):
    Year = models.DateField(auto_now=False, auto_now_add=False)
    Etudiant = models.ForeignKey(Student, on_delete=models. SET_NULL)
    Filiere = models.ForeignKey(Filiere, on_delete=models. SET_NULL)

    def __str__(self):
        return f"{self.Etudiant} --{self.Filiere} --{self.Year}"