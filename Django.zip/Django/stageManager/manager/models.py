from typing import Iterable
from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager

# Create your models here.

class User(AbstractUser):
    class Role(models.TextChoices):
        ADMIN="ADMIN", 'ADMIN'
        PROF="PROF", 'PROF'
        ETUDIANT="ETUDIANT", 'ETUDIANT'

    base_role=Role.ADMIN
    role = models.CharField(max_length = 20, choices= Role)
    

    
    
    #CIN
    CIN=models.CharField(max_length=20, unique=True)
    #adresse
    adresse=models.TextField(max_length=150,blank=True,null=True)
    #tel
    tel=models.CharField(max_length=40,blank=True,null=True)

    #N_apog
    Napog=models.IntegerField(default=0,blank=True,null=True)
    #CNE
    CNE=models.CharField(max_length=50,blank=True,null=True)
    #date_n
    dateN= models.DateField(auto_now=False, auto_now_add=False, null=True,blank=True)
    #lieux_n
    lieuxN = models.CharField(max_length = 50,blank=True,null=True)
    
    
    #spc
    SPC = models.CharField(max_length = 50,blank=True,null=True)
    def save(self, *args, **kwargs):
        if not self.pk:
            self.role=self.base_role
            return super().save(*args, **kwargs)




class ProfManager(BaseUserManager):
    def get_queryset(self, *args, **kwargs):
        result=super().get_queryset(*args, **kwargs)
        return result.filter(role=User.Role.PROF)
        

class Prof(User):
    base_role=User.Role.PROF
    prof=ProfManager()
    class Meta:
        proxy=True

class StudentManager(BaseUserManager):
    def get_queryset(self, *args, **kwargs):
        result=super().get_queryset(*args, **kwargs)
        return result.filter(role=User.Role.ETUDIANT)
    
        

class Student(User):
    base_role=User.Role.ETUDIANT
    student=StudentManager()
    class Meta:
        proxy=True
