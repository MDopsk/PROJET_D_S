from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from .models import Dossiers, Student, StudenttFiliere, Domaine, Filiere, Prof_Filiere
from django.db import IntegrityError
from django.contrib import messages
from django.urls import reverse

# Create your views here.
def index(request):
    user=None
    if request.method=='POST':
        username = request.POST["CIN"]
        password = request.POST["PW"]
        user = authenticate(request, username=username, password=password)
        if user is not None:
        # Redirect to a success page.

            if user.role=="ETUDIANT":
                login(request, user)
                return redirect('FiliereEtud')
            elif user.role=="PROF":
                login(request, user)
                return redirect('filiereProf')
        else:
            # Return an 'invalid login' error message.
            messages.error(request, 'CINE ou mot de passe incorrect')
            return redirect('index')
    else:
    
        return render(request, 'manager/index.html', {'user': user}) 
    
def home(request, niveau, nom_filier, year, cin):
   if request.user.is_authenticated:
        if request.user.role == 'PROF' :
            
            e=Student.student.get(username=cin)
            dossiers = Dossiers.objects.filter(Student =e, Niveau=niveau, Nom_filiere=nom_filier, Year=f'{year}-01-01').order_by('Type')
            context = {'dossiers':dossiers, 'user_name':e.username,  'first_name':e.first_name, 'last_name':e.last_name, 'niveau':niveau, 'nom_filier':nom_filier, 'year':year, 'role':request.user.role }

        else:
            dossiers = Dossiers.objects.filter(Student =request.user, Niveau=niveau, Nom_filiere=nom_filier, Year=f'{year}-01-01').order_by('Type')
            context = {'dossiers':dossiers, 'user_name':request.user.username,  'first_name':request.user.first_name, 'last_name':request.user.last_name, 'niveau':niveau, 'nom_filier':nom_filier, 'year':year}
        return render(request, 'manager/home.html',context = context)
   
   else:
        return redirect('index')

def erreur(request):
    return render(request, 'manager/erreur.html')

def newdossier(request, niveau, nom_filier, year):
   
    if request.method=='POST':
        typ = request.POST['Type']
        rapport=request.POST['Rapport']
        dossier=request.POST['Dossier']
        sujet=request.POST['Sujet']
        encadrant=request.POST['Encadrant']
        domaine=request.POST['Domaine']
        student=request.user
        d=Dossiers.objects.create(Type=typ, Rapport=rapport, Doss=dossier, Sujet=sujet, Encadrant=encadrant, Domaine=domaine, Nom_filiere=nom_filier,  Year=f"{year}-01-01", Niveau=niveau,  Student=student)
        d.save()

        url = reverse('home', kwargs={'niveau': niveau, 'nom_filier':nom_filier, 'year':year, 'cin':None})
        return redirect(url)
    else:
        f=Filiere.objects.get(Nom_filiere=nom_filier)
        sf = StudenttFiliere.objects.get(Etudiant = request.user, Niveau=niveau, Year=f'{year}-01-01' , Filiere=f)
        d = Domaine.objects.filter(filiere = sf.Filiere.pk)
        pfs=Prof_Filiere.objects.filter(Niveau=niveau, filiere=f, Year=f'{year}-01-01')
        profs=[]
        for pf in pfs:
            profs.append(pf.prof)

        
        return render(request, 'manager/newdossier.html', { 'TypesStage': Dossiers.TYPES , 'domaines': d, 'niveau':niveau , 'nom_filier':nom_filier, 'year':year, 'profs':profs })
    
def deletedossier(request, pk):
    d=Dossiers.objects.get(pk=pk)
    niveau=d.Niveau
    nom_filier=d.Nom_filiere
    year=d.Year
    
    d.delete()
    url = reverse('home', kwargs={'niveau':niveau , 'nom_filier':nom_filier, 'year':year.year, 'cin':None })
    return redirect(url)

def afficherdossier(request, pk):
    if request.method == 'POST':
        d = Dossiers.objects.get(pk=pk)
        val = request.POST.get('val')
        if val == "on":
            d.ValidationProf = 1
        else:
            d.ValidationProf = 0
        d.save()
        checked=d.ValidationProf
        context = { 'dossier':d, 'checked': checked }
        return render(request, 'manager/afficherdossier.html', context=context)
    d = Dossiers.objects.get(pk=pk)
    checked=d.ValidationProf
    context = { 'dossier':d, 'checked': checked}
    return render(request, 'manager/afficherdossier.html', context=context)

def updatedossier(request, pk):
    if request.method =='POST':
        
        typ=request.POST['Type']
        rapport=request.POST['Rapport']
        doss=request.POST['Dossier']
        sujet=request.POST['Sujet']
        encadrant=request.POST['Encadrant']
        domaine=request.POST['Domaine']
        

        dossier = Dossiers.objects.get(pk=pk)

        dossier.Type = typ
        dossier.Rapport=rapport
        dossier.Doss =doss
        dossier.Sujet =sujet
        dossier.Encadrant=encadrant
        dossier.Domaine=domaine
        dossier.save()
        url = reverse('home', kwargs={'niveau': dossier.Niveau, 'nom_filier':dossier.Nom_filiere, 'year':dossier.Year.year , 'cin':None})
        return redirect(url)
    
    
    dossier = Dossiers.objects.get(pk=pk)
    f=Filiere.objects.get(Nom_filiere=dossier.Nom_filiere)
    sf = StudenttFiliere.objects.get(Etudiant = request.user, Niveau=dossier.Niveau, Year=f'{dossier.Year.year}-01-01' , Filiere=f)
    d = Domaine.objects.filter(filiere = sf.Filiere.pk)

    pfs=Prof_Filiere.objects.filter(Niveau=dossier.Niveau, Year=f'{dossier.Year.year}-01-01' , filiere=f)
    profs=[]
    for pf in pfs:
        data={'prof':pf.prof, 'name':pf.prof.first_name+' '+pf.prof.last_name}
        profs.append(data)
    context = { 'dossier':dossier, 'TypesStage': Dossiers.TYPES , 'domaines': d, 'profs':profs}
    return render(request, 'manager/updatedossier.html', context=context)

def deconexion(request):
    logout(request)
    return redirect('index')

def register(request):
    if request.method =='POST':
        Napog=request.POST['Napog']
        CIN=request.POST['CIN']
        CNE=request.POST['CNE']
        Nom=request.POST['Nom']
        prenom=request.POST['prenom']
        adresse=request.POST['adresse']
        tel=request.POST['tel']
        DateN=request.POST['DateN']
        LieuxN=request.POST['LieuxN']
        pw1=request.POST['pw1']
        pw2=request.POST['pw2']

        

        if pw1 != pw2:
            erreur ="Les mots de passe ne correspondent pas. Veuillez les saisir à nouveau."
            context = {'register': True, 'erreur':erreur, 'Napog':Napog, 'CIN':CIN, 'CNE':CNE, 'Nom':Nom, 'prenom':prenom,'adresse':adresse, 'tel':tel, 'DateN':DateN, 'LieuxN':LieuxN}
            return render(request, 'manager/enregistrement.html', context=context)
    
        Student.objects.create_user(Napog=Napog, username=CIN, CNE=CNE, first_name=Nom, last_name=prenom, adresse=adresse,  tel=tel, dateN=DateN, lieuxN=LieuxN, password=pw1)
        
        return redirect('index')
    context = {'register': True, }
    return render(request, 'manager/enregistrement.html', context=context)

def filiereEtudiant(request):
    if request.user.is_authenticated:
        FiliereEtud = StudenttFiliere.objects.filter(Etudiant =request.user)
    
        context = {'Filieres':FiliereEtud, 'user_name':request.user.username,  'first_name':request.user.first_name, 'last_name':request.user.last_name}
        return render(request, 'manager/FiliereEtud.html',context = context)
    else:
        return redirect('index')

def deleteFiliere(request, pk, niveau, year):
    #si valider ou commenter n'est pas effacer
   
    if request.method == 'POST':
        f= Filiere.objects.get(pk=pk)
        s=request.user
        sf = StudenttFiliere.objects.get(Etudiant=s,Filiere=f,Niveau=niveau,Year=f"{year}-01-01")
        dossiers = Dossiers.objects.filter(Student=s, Nom_filiere=f.Nom_filiere, Niveau=niveau, Year=f"{year}-01-01")
        for dossier in dossiers:
            dossier.delete()
        sf.delete()
        return redirect('FiliereEtud')

def newFiliere(request):
       
    if request.method=='POST':
        pk=request.POST['NomFiliere']
        niveau=request.POST['niveau']
        annee=request.POST['Annee']
        student=request.user
        
        f=Filiere.objects.get(pk=pk)
        try:
            se =StudenttFiliere.objects.create(Etudiant=student, Filiere=f, Year=f"{annee}-01-01", Niveau=niveau)  # Crée un nouvel objet
            se.save()
        except IntegrityError as e:
            error_message = "Une erreur s'est produite : Cette Session existe déjà. Veuillez saisir une session unique."
            messages.error(request, error_message)
        return redirect('FiliereEtud')
    else:
        sf = Filiere.objects.all()
        n=StudenttFiliere.NIVEAUX
        
        return render(request, 'manager/newFiliere.html', {'Filieres': sf, 'Niveaux':n})
    
def filiereProf(request):
    if request.user.is_authenticated:
        FiliereProfe = Prof_Filiere.objects.filter(prof =request.user)
        context = {'Filieres':FiliereProfe, 'user_name':request.user.username,  'first_name':request.user.first_name, 'last_name':request.user.last_name}
        return render(request, 'manager/FiliereProf.html',context = context)
    else:
        return redirect('index')

def etudiantsFiliere(request, niveau, filiere, Year):
    f=Filiere.objects.get(Nom_filiere=filiere)
    etudiantsFil=StudenttFiliere.objects.filter(Filiere=f,Niveau=niveau, Year=f'{Year}-01-01', )
    etudiants=[]
    for etudiant in etudiantsFil:
        etudiants.append(etudiant.Etudiant)
    context={'etudiants':etudiants, 'filiere':filiere, 'niveau':niveau, 'Year':Year, 'user_name':request.user.username,  'first_name':request.user.first_name, 'last_name':request.user.last_name }
    return render(request, 'manager/etudiantsFiliere.html',context = context)

