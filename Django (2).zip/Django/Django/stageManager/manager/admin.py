from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User,Dossiers


class CostumUser(UserAdmin):
    model=User
    fieldsets = UserAdmin.fieldsets + (
        (None, {'fields': ('role','CIN','adresse','tel','Napog','CNE','dateN','lieuxN','SPC')}),
    )



admin.site.register(User, CostumUser)
admin.site.register(Dossiers)
# Register your models here.
