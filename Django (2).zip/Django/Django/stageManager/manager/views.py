from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from .models import Dossiers

# Create your views here.
def index(request):
    user=None
    if request.method=='POST':
        username = request.POST["CIN"]
        password = request.POST["PW"]
        user = authenticate(request, username=username, password=password)
        if user is not None:
        # Redirect to a success page.
            login(request, user)
            return redirect('home')
        else:
        # Return an 'invalid login' error message.
            return redirect('erreur')
    else:
    
    
        return render(request, 'manager/index.html', {'user': user}) 
    
       

def home(request):
   if request.user.is_authenticated:
        dossiers = Dossiers.objects.filter(Student =request.user)
        context = {'dossiers':dossiers, 'user_name':request.user.username}
        return render(request, 'manager/home.html',context = context)
   else:
        return redirect('erreur')


def erreur(request):
    return render(request, 'manager/erreur.html')


def newdossier(request):
    if request.method=='POST':
        type = request.POST['Type']
        rapport=request.POST['Rapport']
        dossier=request.POST['Dossier']
        sujet=request.POST['Sujet']
        encadrant=request.POST['Encadrant']
        domaine=request.POST['Domaine']
        student=request.user
        d=Dossiers.objects.create(Type=type, Rapport=rapport, Dossier=dossier, Sujet=sujet, Encadrant=encadrant, Domaine=domaine, Student=student )
        d.save()
        return redirect('home')
    else:

        return render(request, 'manager/newdossier.html')
    
def deletedossier(request, pk):
    
    Dossiers.objects.filter(pk=pk).delete()
    return redirect('home')

def afficherdossier(request, pk):
    dossier = Dossiers.objects.get(pk=pk)
    context = { 'dossier':dossier }
    return render(request, 'manager/afficherdossier.html', context=context)

def updatedossier(request, pk):
    
    if request.method =='POST':
        type=request.POST.get('Type')
        rapport=request.POST.get('Rapport')
        dossier=request.POST.get('Dossier')
        sujet=request.POST.get('Sujet')
        encadrant=request.POST.get('Encadrant')
        domaine=request.POST.get('Domaine')
        
        dossier = Dossiers.objects.get(pk=pk)

        dossier.Type = str(type)
        dossier.Rapport=str(rapport)
        dossier.Dossier =str(dossier)
        dossier.Sujet =str(sujet)
        dossier.Encadrant=str(encadrant)
        dossier.Domaine=str(domaine)
        dossier.save()
        return redirect('home')
    
    dossier = Dossiers.objects.get(pk=pk)
    
    context = { 'dossier':dossier }
    return render(request, 'manager/updatedossier.html', context=context)




def deconexion(request):
    logout(request)
    return redirect('index')