from django.contrib import admin
from django.urls import path
from .import views

urlpatterns = [
    path('', views.index, name='index'),
    path('home/', views.home, name='home'),
    path('erreur/', views.erreur, name='erreur'),
    path('newdossier/', views.newdossier, name='newdossier'),
    path('delete/<int:pk>', views.deletedossier, name='deletedossier'),
    path('afficherdossier/<int:pk>', views.afficherdossier, name='afficherdossier'),
    path('updatedossier/<int:pk>', views.updatedossier, name='updatedossier'),
    path('logout/', views.deconexion, name='logout'),
    
]


